package com.cg.gtf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.gtf.entity.QueryMaster;
import com.cg.gtf.service.IGtfService;



@Controller//used to control the requests
public class GtfController {
	
	@Autowired//used to auto wire to other classes
	IGtfService service;
	QueryMaster queryMaster=null;
	QueryMaster queryMaster1=null;
	@RequestMapping(value="all")//maps request from url
	public String home()
	{
		return "home";//returns view page
	}
	
	@RequestMapping(value="search",method=RequestMethod.GET)//maps request from url
	public ModelAndView search(@RequestParam("queryId") int id)
	{
		System.out.println(id);
		QueryMaster bean=null;
		bean=service.search(id);
		queryMaster=bean;
		System.out.println(bean);
		
		if(bean==null)
			return new ModelAndView("error","data",queryMaster1);//returns model and view object
		else
			return new ModelAndView("update","data",bean);//returns model and view object
	}
	
	@RequestMapping(value="sucess",method=RequestMethod.GET)//maps request from url
	public ModelAndView success()
	{
		return new ModelAndView("success","data",queryMaster);//returns model and view object
	}
	
}

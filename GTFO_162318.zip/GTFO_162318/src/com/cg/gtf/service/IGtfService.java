package com.cg.gtf.service;

import com.cg.gtf.entity.QueryMaster;

public interface IGtfService {
public 	boolean addQuery(QueryMaster query_Master);
public	QueryMaster search(int id);
}

package com.cg.gtf.dao;

import com.cg.gtf.entity.QueryMaster;

public interface IGtfDao {
	public boolean addQuery(QueryMaster query_Master);
	public QueryMaster search(int id);
}

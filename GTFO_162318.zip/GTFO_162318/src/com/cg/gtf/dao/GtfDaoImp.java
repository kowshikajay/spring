package com.cg.gtf.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.gtf.entity.QueryMaster;

@Repository
public class GtfDaoImp implements IGtfDao {

	@PersistenceContext//CONTAINS entity manager factory
	EntityManager em;
	@Override
	public boolean addQuery(QueryMaster query_Master) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public QueryMaster search(int id) {
		// TODO Auto-generated method stub
		
		QueryMaster bean=null;
		bean=em.find(QueryMaster.class, id);
		return bean;
	}

}
